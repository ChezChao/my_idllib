The folder coyote/public contains IDL programs that are written
and supported by someone other than David Fanning. Nevertheless,
these programs are written in a way that makes them compatible
with the Coyote Graphics System (CGS). They are distributed
with the Coyote Library as a way to make them easily available to the
IDL programming community. If you have a question about a routine,
wish to make a suggestion about an enhancement, or find a bug,
please contact the author directly.